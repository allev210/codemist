/**
 * TopDesk REST API client.
 *
 * Docs: https://<your-instance>/tas/api/incidents
 *
 * Authentication: Application password (recommended) or Basic auth.
 * Create an application password in TopDesk:
 *   Profile → Settings → Application passwords → New
 * Then set:
 *   TOPDESK_URL      = https://yourcompany.topdesk.net
 *   TOPDESK_USERNAME = your-topdesk-login
 *   TOPDESK_APP_PASSWORD = generated-application-password
 */

const { logger } = require('./logger');

function getAuthHeader() {
  const user = process.env.TOPDESK_USERNAME;
  const pass = process.env.TOPDESK_APP_PASSWORD;
  if (!user || !pass) {
    throw new Error('TOPDESK_USERNAME and TOPDESK_APP_PASSWORD must be set in environment');
  }
  return `Basic ${Buffer.from(`${user}:${pass}`).toString('base64')}`;
}

/**
 * Creates a new incident in TopDesk.
 * @param {object} incident – body produced by mapper.js
 * @returns {object} TopDesk incident object (includes id, number)
 */
async function createTopDeskIncident(incident) {
  const baseUrl = process.env.TOPDESK_URL?.replace(/\/$/, '');
  if (!baseUrl) {
    throw new Error('TOPDESK_URL must be set in environment');
  }

  const url = `${baseUrl}/tas/api/incidents`;

  logger.debug('Calling TopDesk API', { url, brief: incident.briefDescription });

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': getAuthHeader(),
    },
    body: JSON.stringify(incident),
  });

  const body = await response.json().catch(() => null);

  if (!response.ok) {
    const msg = body?.message ?? body?.errorMessage ?? response.statusText;
    throw new Error(`TopDesk API error ${response.status}: ${msg}`);
  }

  return body; // { id, number, briefDescription, status, … }
}

/**
 * (Optional) Look up an existing incident by Mist alarm ID stored in optionalFields1.text1.
 * Useful for deduplication – check before creating a new ticket.
 */
async function findExistingIncident(mistAlarmId) {
  const baseUrl = process.env.TOPDESK_URL?.replace(/\/$/, '');
  const url = `${baseUrl}/tas/api/incidents?optionalField1=${encodeURIComponent(mistAlarmId)}`;

  const response = await fetch(url, {
    headers: { 'Authorization': getAuthHeader() },
  });

  if (!response.ok) return null;

  const results = await response.json().catch(() => []);
  return results[0] ?? null;
}

module.exports = { createTopDeskIncident, findExistingIncident };
