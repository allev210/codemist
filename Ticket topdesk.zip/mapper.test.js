const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { mapMarvisToTopDesk } = require('../src/mapper');

// ─── Sample Mist payloads ─────────────────────────────────────────────────────
const dhcpEvent = {
  id:        'alarm-abc-123',
  type:      'dhcp_failure',
  display:   'DHCP Failure',
  group:     'marvis',
  severity:  'critical',
  site_id:   'site-uuid-001',
  site_name: 'HQ Brussels',
  org_id:    'org-uuid-001',
  timestamp: 1713200000,
  count:     14,
  solution:  'Check DHCP server 10.0.0.1 reachability from the gateway.',
};

const badCableEvent = {
  id:        'alarm-def-456',
  type:      'bad_cable',
  display:   'Bad cable',
  group:     'marvis',
  severity:  'critical',
  site_name: 'Branch Antwerp',
  timestamp: 1713200100,
  hostnames: ['sw-antwerp-01'],
};

describe('mapMarvisToTopDesk', () => {
  it('maps a DHCP failure to the correct TopDesk fields', () => {
    const result = mapMarvisToTopDesk(dhcpEvent, { org_name: 'Acme Corp' });

    assert.ok(result.briefDescription.includes('DHCP'), 'Brief description should mention DHCP');
    assert.ok(result.briefDescription.includes('HQ Brussels'), 'Brief description should include site name');
    assert.equal(result.category.name, 'Network');
    assert.equal(result.subcategory.name, 'DHCP');
    assert.equal(result.priority.name, 'P2');
    assert.equal(result.urgency.name, 'High');
    assert.equal(result.impact.name, 'Department');
    assert.ok(result.request.includes('14'), 'Request body should include affected count');
    assert.ok(result.request.includes('Check DHCP server'), 'Request body should include Marvis solution');
    assert.equal(result.optionalFields1.text1, 'alarm-abc-123');
    assert.equal(result.optionalFields1.text4, 'dhcp_failure');
  });

  it('maps a bad cable event', () => {
    const result = mapMarvisToTopDesk(badCableEvent);

    assert.equal(result.subcategory.name, 'Wired');
    assert.equal(result.priority.name, 'P3');
    assert.ok(result.request.includes('sw-antwerp-01'), 'Request should list affected device');
    assert.ok(result.request.includes('Inspect physical cable'), 'Request should contain default recommendation');
  });

  it('falls back gracefully for unknown symptom types', () => {
    const unknownEvent = {
      type: 'some_new_marvis_symptom',
      severity: 'warn',
      site_name: 'Test site',
      timestamp: 1713200200,
    };
    const result = mapMarvisToTopDesk(unknownEvent);

    assert.equal(result.category.name, 'Network');
    assert.equal(result.priority.name, 'P3'); // warn → P3
    assert.ok(result.briefDescription.length > 0);
  });
});

console.log('Tests completed.');
