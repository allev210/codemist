/**
 * Maps a Mist Marvis Action / alarm event to a TopDesk incident body.
 *
 * TopDesk API docs:  https://<your-instance>/tas/api/incidents
 * Mist alarm topics: alarms, marvis_events
 */

// ─── Symptom → TopDesk category / priority mapping ───────────────────────────
const SYMPTOM_MAP = {
  dhcp_failure:        { category: 'Network', subcategory: 'DHCP',           priority: 'P2', impact: 'Department' },
  dns_failure:         { category: 'Network', subcategory: 'DNS',            priority: 'P2', impact: 'Department' },
  auth_failure:        { category: 'Network', subcategory: 'Authentication', priority: 'P2', impact: 'Department' },
  bad_cable:           { category: 'Network', subcategory: 'Wired',          priority: 'P3', impact: 'Person'     },
  port_flap:           { category: 'Network', subcategory: 'Switch',         priority: 'P3', impact: 'Person'     },
  port_stuck:          { category: 'Network', subcategory: 'Switch',         priority: 'P2', impact: 'Department' },
  missing_vlan:        { category: 'Network', subcategory: 'Switch',         priority: 'P2', impact: 'Department' },
  switch_offline:      { category: 'Network', subcategory: 'Switch',         priority: 'P1', impact: 'Site'       },
  gateway_down:        { category: 'Network', subcategory: 'Gateway/WAN',    priority: 'P1', impact: 'Site'       },
  bad_wan_uplink:      { category: 'Network', subcategory: 'Gateway/WAN',    priority: 'P1', impact: 'Site'       },
  intermittent_wan:    { category: 'Network', subcategory: 'Gateway/WAN',    priority: 'P2', impact: 'Department' },
  vpn_path_down:       { category: 'Network', subcategory: 'VPN',            priority: 'P2', impact: 'Department' },
  arp_failure:         { category: 'Network', subcategory: 'Layer 2',        priority: 'P2', impact: 'Department' },
  ap_offline:          { category: 'Network', subcategory: 'Wireless',       priority: 'P2', impact: 'Department' },
  ap_health_failed:    { category: 'Network', subcategory: 'Wireless',       priority: 'P2', impact: 'Department' },
  insufficient_coverage: { category: 'Network', subcategory: 'Wireless',     priority: 'P3', impact: 'Person'     },
  high_cpu:            { category: 'Network', subcategory: 'Infrastructure', priority: 'P2', impact: 'Department' },
  stp_loop:            { category: 'Network', subcategory: 'Switch',         priority: 'P1', impact: 'Site'       },
  device_problem:      { category: 'Network', subcategory: 'Infrastructure', priority: 'P2', impact: 'Department' },
};

// ─── Severity → TopDesk urgency ───────────────────────────────────────────────
const SEVERITY_URGENCY = {
  critical: 'High',
  warn:     'Medium',
  info:     'Low',
};

// ─── Main mapper ──────────────────────────────────────────────────────────────
function mapMarvisToTopDesk(event, envelope = {}) {
  const symptomKey  = normalizeSymptomKey(event);
  const mapping     = SYMPTOM_MAP[symptomKey] ?? defaultMapping(event);
  const siteName    = event.site_name   ?? envelope.site_name   ?? 'Unknown site';
  const orgName     = event.org_name    ?? envelope.org_name    ?? 'Unknown org';
  const timestamp   = formatTimestamp(event.timestamp ?? event.last_seen ?? Date.now() / 1000);
  const urgency     = SEVERITY_URGENCY[event.severity?.toLowerCase()] ?? 'Medium';
  const affectedCount = event.count ?? event.num_clients ?? event.num_aps ?? null;

  const briefDescription = buildBriefDescription(event, siteName);
  const requestBody      = buildRequestBody(event, siteName, orgName, timestamp, affectedCount, mapping);

  return {
    // ── Required TopDesk fields ──
    briefDescription,
    request: requestBody,

    // ── Optional routing fields (configure caller/operator in .env) ──
    ...(process.env.TOPDESK_CALLER_ID    && { caller:    { id: process.env.TOPDESK_CALLER_ID }   }),
    ...(process.env.TOPDESK_OPERATOR_ID  && { operator:  { id: process.env.TOPDESK_OPERATOR_ID } }),
    ...(process.env.TOPDESK_OPERATOR_GROUP_ID && {
      operatorGroup: { id: process.env.TOPDESK_OPERATOR_GROUP_ID }
    }),

    // ── Classification ──
    category:    { name: mapping.category    },
    subcategory: { name: mapping.subcategory },
    urgency:     { name: urgency             },
    impact:      { name: mapping.impact      },
    priority:    { name: mapping.priority    },
    status:      'firstLine',

    // ── Metadata stored as free-text for traceability ──
    optionalFields1: {
      text1: event.id      ?? '',               // Mist alarm/action ID
      text2: event.site_id ?? envelope.site_id ?? '',
      text3: event.org_id  ?? envelope.org_id  ?? '',
      text4: symptomKey,
    },
  };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function normalizeSymptomKey(event) {
  // Mist uses different field names across alarm vs Marvis action payloads
  const raw = event.symptom ?? event.type ?? event.key ?? event.alarm_type ?? '';
  return raw.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
}

function defaultMapping(event) {
  const sev = event.severity?.toLowerCase();
  return {
    category:    'Network',
    subcategory: 'Infrastructure',
    priority:    sev === 'critical' ? 'P2' : 'P3',
    impact:      sev === 'critical' ? 'Department' : 'Person',
  };
}

function buildBriefDescription(event, siteName) {
  const display = event.display ?? event.reason ?? normalizeSymptomKey(event).replace(/_/g, ' ');
  return `[Mist] ${capitalize(display)} – ${siteName}`;
}

function buildRequestBody(event, siteName, orgName, timestamp, affectedCount, mapping) {
  const lines = [
    `Mist Marvis AI has detected an issue that requires attention.`,
    ``,
    `═══ Event details ═══`,
    `Type        : ${event.display ?? event.type ?? event.key ?? 'N/A'}`,
    `Severity    : ${capitalize(event.severity ?? 'unknown')}`,
    `Site        : ${siteName}`,
    `Organisation: ${orgName}`,
    `Detected at : ${timestamp}`,
  ];

  if (affectedCount !== null) {
    lines.push(`Affected    : ${affectedCount} device(s)/client(s)`);
  }

  if (event.hostnames?.length) {
    lines.push(`Devices     : ${event.hostnames.slice(0, 5).join(', ')}${event.hostnames.length > 5 ? ' …' : ''}`);
  }
  if (event.aps?.length) {
    lines.push(`Access pts  : ${event.aps.slice(0, 5).join(', ')}`);
  }
  if (event.switches?.length) {
    lines.push(`Switches    : ${event.switches.slice(0, 5).join(', ')}`);
  }

  lines.push(``, `═══ Marvis recommended action ═══`);

  if (event.solution) {
    lines.push(event.solution);
  } else {
    lines.push(defaultRecommendation(mapping));
  }

  if (event.url) {
    lines.push(``, `Mist dashboard: ${event.url}`);
  }

  lines.push(``, `── This ticket was opened automatically by the Mist ↔ TopDesk middleware ──`);
  return lines.join('\n');
}

function defaultRecommendation(mapping) {
  const recs = {
    DHCP:           'Verify DHCP server reachability and pool availability. Check relay configuration on the switch/gateway.',
    DNS:            'Verify DNS server reachability from the site gateway. Check firewall rules for UDP/TCP port 53.',
    Authentication: 'Check RADIUS server connectivity and certificate validity. Review 802.1X supplicant logs.',
    Wired:          'Inspect physical cable and SFP/RJ45 port. Replace cable or run copper diagnostics on the switch.',
    Switch:         'Review switch logs, check STP topology, verify VLAN configuration on uplink ports.',
    'Gateway/WAN':  'Check WAN link status, ISP circuit health, and BGP/routing table on the gateway.',
    VPN:            'Verify IKE phase 1/2 settings and peer reachability. Review VPN tunnel logs.',
    Wireless:       'Review AP logs, check uplink port status, validate RF configuration.',
    Infrastructure: 'Review device logs and resource utilisation. Escalate to network team if unresolved.',
  };
  return recs[mapping.subcategory] ?? 'Please investigate the Mist dashboard for further details.';
}

function capitalize(str) {
  return str ? str.charAt(0).toUpperCase() + str.slice(1) : '';
}

function formatTimestamp(epochSeconds) {
  return new Date(epochSeconds * 1000).toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
}

module.exports = { mapMarvisToTopDesk };
