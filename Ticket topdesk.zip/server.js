const express = require('express');
const crypto = require('crypto');
const { mapMarvisToTopDesk } = require('./mapper');
const { createTopDeskIncident } = require('./topdesk');
const { logger } = require('./logger');

const app = express();
app.use(express.json());

// ─── Webhook signature verification (optional but recommended) ────────────────
function verifyMistSignature(req, res, next) {
  const secret = process.env.MIST_WEBHOOK_SECRET;
  if (!secret) return next(); // Skip if not configured

  const signature = req.headers['x-mist-signature'];
  if (!signature) {
    logger.warn('Missing Mist webhook signature');
    return res.status(401).json({ error: 'Missing signature' });
  }

  const hmac = crypto
    .createHmac('sha256', secret)
    .update(JSON.stringify(req.body))
    .digest('hex');

  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(hmac))) {
    logger.warn('Invalid Mist webhook signature');
    return res.status(401).json({ error: 'Invalid signature' });
  }
  next();
}

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ─── Webhook endpoint ─────────────────────────────────────────────────────────
app.post('/webhook/mist', verifyMistSignature, async (req, res) => {
  const payload = req.body;

  logger.info('Received Mist webhook', {
    topic: payload.topic,
    org_id: payload.org_id,
    site_id: payload.site_id,
    event_count: payload.events?.length ?? 1,
  });

  // Accept quickly so Mist doesn't retry
  res.status(202).json({ received: true });

  // Mist sends alarms and Marvis actions under different topics
  const events = payload.events ?? [payload];

  for (const event of events) {
    try {
      // Only process Marvis / alarm events
      const isMarvis =
        event.group === 'marvis' ||
        payload.topic === 'alarms' ||
        payload.topic === 'marvis_events';

      if (!isMarvis) {
        logger.debug('Skipping non-Marvis event', { type: event.type });
        continue;
      }

      // Filter by severity (skip info-level noise by default)
      const minSeverity = process.env.MIN_SEVERITY ?? 'warn';
      if (!isSeverityMet(event.severity, minSeverity)) {
        logger.debug('Skipping low-severity event', { severity: event.severity });
        continue;
      }

      const incident = mapMarvisToTopDesk(event, payload);
      const result = await createTopDeskIncident(incident);

      logger.info('TopDesk incident created', {
        incident_number: result.number,
        incident_id: result.id,
        marvis_type: event.type ?? event.key,
        site: event.site_name ?? payload.site_name,
      });
    } catch (err) {
      logger.error('Failed to create TopDesk incident', {
        error: err.message,
        event_type: event.type,
      });
    }
  }
});

// ─── Severity filter ──────────────────────────────────────────────────────────
const SEVERITY_ORDER = ['info', 'warn', 'critical'];
function isSeverityMet(eventSeverity, minSeverity) {
  const ei = SEVERITY_ORDER.indexOf(eventSeverity?.toLowerCase());
  const mi = SEVERITY_ORDER.indexOf(minSeverity?.toLowerCase());
  return ei >= mi;
}

const PORT = process.env.PORT ?? 3000;
app.listen(PORT, () => logger.info(`Middleware listening on port ${PORT}`));

module.exports = app;
