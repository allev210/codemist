#!/usr/bin/env node
/**
 * Mist Unassigned Port Monitor  (site-by-site)
 * ─────────────────────────────────────────────────────────────────────────────
 * Every CHECK_INTERVAL_MINUTES the script:
 *   1. Lists all sites in the org
 *   2. Per site → fetches switch port stats (site_ports, up=true)
 *   3. Identifies ports with NO explicit profile/port_usage assignment
 *      (compares against each device's port_config in the site device config)
 *   4. Queries Insights (SW_PORT_UP device events) scoped to the site
 *      for the last windowMins to confirm the port came up in this window
 *   5. Sends an HTML alert email for any matching ports
 *
 * Requirements:
 *   npm install nodemailer dotenv
 *   Node 18+ has built-in fetch — or:  npm install node-fetch
 *
 * Setup:
 *   cp .env.example .env   ← fill in values
 *   node mist-unassigned-port-monitor-v2.js
 */

'use strict';

// ── Load .env ─────────────────────────────────────────────────────────────────
const path = require('path');
const fs   = require('fs');
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) require('dotenv').config({ path: envPath });
else try { require('dotenv').config(); } catch (_) {}

// ── Config ────────────────────────────────────────────────────────────────────
const CFG = {
  token:       process.env.MIST_API_TOKEN,
  orgId:       process.env.MIST_ORG_ID,
  base:        'https://api.mist.com/api/v1',
  windowMins:  parseInt(process.env.CHECK_INTERVAL_MINUTES || '15', 10),
  dryRun:      process.env.DRY_RUN === 'true',
  smtp: {
    host:   process.env.SMTP_HOST,
    port:   parseInt(process.env.SMTP_PORT || '587', 10),
    secure: process.env.SMTP_SECURE === 'true',
    user:   process.env.SMTP_USER,
    pass:   process.env.SMTP_PASS,
  },
  mail: {
    from: process.env.EMAIL_FROM,
    to:   (process.env.EMAIL_TO || '').split(',').map(s => s.trim()).filter(Boolean),
  },
};

// ── Validation ────────────────────────────────────────────────────────────────
function validate() {
  if (!CFG.token) die('MIST_API_TOKEN not set.');
  if (!CFG.orgId) die('MIST_ORG_ID not set.');
  if (!CFG.dryRun) {
    const need = ['SMTP_HOST', 'SMTP_USER', 'SMTP_PASS', 'EMAIL_FROM', 'EMAIL_TO'];
    const miss = need.filter(k => !process.env[k]);
    if (miss.length) die(`Missing: ${miss.join(', ')}. Set DRY_RUN=true to skip email.`);
  }
}
function die(m) { console.error('[FATAL]', m); process.exit(1); }

// ── Fetch wrapper ─────────────────────────────────────────────────────────────
let _fetch;
async function apiFetch(url, params = {}) {
  if (!_fetch) {
    _fetch = typeof globalThis.fetch === 'function'
      ? globalThis.fetch.bind(globalThis)
      : (await import('node-fetch')).default;
  }
  const u = new URL(url);
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && v !== '') u.searchParams.set(k, String(v));
  }
  const res  = await _fetch(u.toString(), {
    headers: { Authorization: `Token ${CFG.token}`, 'Content-Type': 'application/json' },
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`HTTP ${res.status} ${u.pathname}: ${text.slice(0, 300)}`);
  return JSON.parse(text);
}

// ── Helper: parse next_cursor into query params ───────────────────────────────
// Mist returns next_cursor as a relative path like:
//   /api/v1/sites/{id}/stats/ports/search?limit=100&search_after=...
// We strip everything up to '?' and re-apply the params.
function cursorParams(cursor) {
  const qi = cursor.indexOf('?');
  if (qi === -1) return {};
  return Object.fromEntries(new URLSearchParams(cursor.slice(qi + 1)).entries());
}

// ── Mist: list all sites ──────────────────────────────────────────────────────
async function getSites() {
  const data = await apiFetch(`${CFG.base}/orgs/${CFG.orgId}/sites`);
  return Array.isArray(data) ? data : (data.results || []);
}

// ── Mist: all UP switch ports for one site (fully paginated) ──────────────────
// Endpoint: GET /sites/{site_id}/stats/ports/search
// Returns search-envelope: { data: [...], has_more, next_cursor, total }
async function getSitePortsUp(siteId) {
  const all = [];
  let cursor = null;

  do {
    const params = cursor
      ? cursorParams(cursor)
      : { device_type: 'switch', up: 'true', limit: 100 };

    const data = await apiFetch(
      `${CFG.base}/sites/${siteId}/stats/ports/search`,
      params,
    );

    const items = data.data || data.results || (Array.isArray(data) ? data : []);
    all.push(...items);
    cursor = (data.has_more && data.next_cursor) ? data.next_cursor : null;
  } while (cursor);

  return all;
}

// ── Mist: SW_PORT_UP events for one site in last windowMins ──────────────────
// Returns Set<"mac:port_id"> (lowercase)
async function getPortUpEvents(siteId) {
  const since = Math.floor(Date.now() / 1000) - CFG.windowMins * 60;
  const keys  = new Set();
  let cursor  = null;

  do {
    const params = cursor
      ? cursorParams(cursor)
      : { type: 'SW_PORT_UP', start: since, limit: 100 };

    const data = await apiFetch(
      `${CFG.base}/sites/${siteId}/devices/events/search`,
      params,
    );

    const events = data.results || (Array.isArray(data) ? data : []);
    for (const ev of events) {
      const mac    = (ev.mac || '').toLowerCase();
      const portId = ev.port_id || '';
      if (mac && portId) keys.add(`${mac}:${portId}`);
    }

    cursor = (data.has_more && data.next_cursor) ? data.next_cursor : null;
  } while (cursor);

  return keys;
}

// ── Mist: build assigned-port map for one site ───────────────────────────────
// GET /sites/{site_id}/devices?type=switch
// Each device has a port_config object: { "ge-0/0/3": { usage: "profile-name", ... } }
// A port is "assigned" if it appears in port_config with a `usage` key.
// Returns: { [macLower]: Set<portId> }
async function getAssignedPortMap(siteId) {
  const map    = {};   // mac → Set of portIds with explicit profile
  let cursor   = null;

  do {
    const params = cursor
      ? cursorParams(cursor)
      : { type: 'switch', limit: 100 };

    const data    = await apiFetch(`${CFG.base}/sites/${siteId}/devices`, params);
    const devices = Array.isArray(data) ? data : (data.results || []);

    for (const dev of devices) {
      const mac        = (dev.mac || '').toLowerCase();
      const portConfig = dev.port_config || {};
      if (!map[mac]) map[mac] = new Set();
      for (const [portId, cfg] of Object.entries(portConfig)) {
        if (cfg && cfg.usage) map[mac].add(portId);
      }
    }

    cursor = (!Array.isArray(data) && data.has_more && data.next_cursor)
      ? data.next_cursor : null;
  } while (cursor);

  return map;
}

// ── Logic: is this port unassigned? ──────────────────────────────────────────
function isUnassigned(port, assignedMap) {
  const mac    = (port.mac || '').toLowerCase();
  const portId = port.port_id || '';
  // If the switch itself has no port_config entries → all ports unassigned
  if (!assignedMap[mac]) return true;
  // If this port has no explicit usage profile → unassigned
  return !assignedMap[mac].has(portId);
}

// ── Core check (runs every interval) ─────────────────────────────────────────
async function runCheck() {
  const t0 = Date.now();
  log('\n' + '─'.repeat(64));
  log(`Check started  ${new Date().toUTCString()}`);

  const alertPorts = [];

  try {
    const sites = await getSites();
    log(`Sites in org   ${sites.length}`);

    for (const site of sites) {
      const { id: siteId, name: siteName } = site;
      log(`\n  ▶ ${siteName}  (${siteId})`);

      // 1. All UP switch ports
      let upPorts;
      try {
        upPorts = await getSitePortsUp(siteId);
      } catch (err) {
        log(`    WARN ports: ${err.message}`);
        continue;
      }
      log(`    UP switch ports        : ${upPorts.length}`);
      if (upPorts.length === 0) continue;

      // 2. Device port_config (tells us which ports have profiles)
      let assignedMap;
      try {
        assignedMap = await getAssignedPortMap(siteId);
      } catch (err) {
        log(`    WARN device config: ${err.message}`);
        assignedMap = {};
      }

      // 3. Filter unassigned UP ports
      const unassigned = upPorts.filter(p => isUnassigned(p, assignedMap));
      log(`    Unassigned + UP        : ${unassigned.length}`);
      if (unassigned.length === 0) continue;

      // 4. SW_PORT_UP events in the last window (site-scoped Insights)
      let recentEvents;
      try {
        recentEvents = await getPortUpEvents(siteId);
      } catch (err) {
        log(`    WARN events: ${err.message}`);
        recentEvents = new Set();
      }
      log(`    SW_PORT_UP events      : ${recentEvents.size}`);

      // 5. Cross-match
      const matched = unassigned.filter(p => {
        const key = `${(p.mac || '').toLowerCase()}:${p.port_id}`;
        return recentEvents.has(key);
      });

      log(`    ★ Matched (unassigned + UP in last ${CFG.windowMins}m): ${matched.length}`);

      for (const p of matched) {
        log(`      → ${p.hostname || p.mac}  ${p.port_id}  ${p.speed}Mbps  ` +
            `neighbor: ${p.neighbor_system_name || 'none'}`);
        alertPorts.push({
          siteName,
          siteId,
          switchMac:    p.mac || '',
          hostname:     p.hostname || p.mac || '',
          portId:       p.port_id || '',
          speed:        p.speed || '',
          neighbor:     p.neighbor_system_name || p.lldp_system_name || '—',
          neighborPort: p.neighbor_port_desc || '',
          poeOn:        p.poe_on ? 'Yes' : 'No',
        });
      }
    }

    if (alertPorts.length === 0) {
      log(`\n✔  No unassigned ports came UP in the last ${CFG.windowMins} minutes.`);
    } else {
      log(`\n⚠️  Sending alert for ${alertPorts.length} port(s)…`);
      await sendAlert(alertPorts);
    }

  } catch (err) {
    log(`ERROR: ${err.message}`);
    if (err.stack) log(err.stack);
  }

  log(`Check finished in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
}

// ── Email ─────────────────────────────────────────────────────────────────────
function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

async function sendAlert(ports) {
  if (CFG.dryRun) {
    log('[DRY RUN] Would send alert email. Ports:');
    console.table(ports);
    return;
  }

  const nodemailer = require('nodemailer');
  const xp = nodemailer.createTransport({
    host: CFG.smtp.host, port: CFG.smtp.port, secure: CFG.smtp.secure,
    auth: { user: CFG.smtp.user, pass: CFG.smtp.pass },
  });

  const rows = ports.map(p => `
    <tr>
      <td>${esc(p.siteName)}</td>
      <td>${esc(p.hostname)}</td>
      <td><code>${esc(p.switchMac)}</code></td>
      <td><strong>${esc(p.portId)}</strong></td>
      <td>${esc(p.speed)} Mbps</td>
      <td>${esc(p.neighbor)}</td>
      <td>${esc(p.neighborPort)}</td>
      <td>${esc(p.poeOn)}</td>
    </tr>`).join('');

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
    body{font-family:Arial,sans-serif;font-size:14px;color:#222;margin:24px}
    h2{color:#c0392b;margin-bottom:6px}
    .sub{color:#555;font-size:13px;margin-bottom:20px}
    table{border-collapse:collapse;width:100%;margin-top:8px}
    th{background:#2c3e50;color:#fff;padding:9px 14px;text-align:left;font-size:13px}
    td{border:1px solid #ddd;padding:8px 14px;vertical-align:top}
    tr:nth-child(even) td{background:#f7f7f7}
    code{font-size:12px;background:#eee;padding:1px 5px;border-radius:3px}
    .footer{margin-top:28px;font-size:11px;color:#999;border-top:1px solid #eee;padding-top:10px}
  </style></head><body>
  <h2>⚠️ Mist — Unassigned Switch Ports Came UP</h2>
  <p class="sub">
    <strong>${ports.length}</strong> port(s) with no profile assignment triggered a
    <code>SW_PORT_UP</code> event in the last <strong>${CFG.windowMins} minutes</strong>.
    These ports are active but outside any switch profile — investigate or assign a profile.
  </p>
  <table>
    <thead>
      <tr>
        <th>Site</th><th>Switch Hostname</th><th>Switch MAC</th>
        <th>Port</th><th>Speed</th><th>LLDP Neighbor</th><th>Neighbor Port</th><th>PoE On</th>
      </tr>
    </thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="footer">
    Checked at ${new Date().toUTCString()} &nbsp;|&nbsp;
    Org: ${CFG.orgId} &nbsp;|&nbsp;
    Mist Unassigned Port Monitor
  </div>
  </body></html>`;

  await xp.sendMail({
    from:    CFG.mail.from,
    to:      CFG.mail.to.join(', '),
    subject: `[Mist Alert] ${ports.length} unassigned port(s) came UP — ${new Date().toUTCString()}`,
    html,
  });
  log(`Email sent → ${CFG.mail.to.join(', ')}`);
}

// ── Scheduler ─────────────────────────────────────────────────────────────────
function log(m) { console.log(`[${new Date().toISOString()}] ${m}`); }

async function main() {
  validate();

  log('Mist Unassigned Port Monitor  (site-by-site)');
  log(`  Org      : ${CFG.orgId}`);
  log(`  Window   : last ${CFG.windowMins} min`);
  log(`  Interval : every ${CFG.windowMins} min`);
  log(`  Dry run  : ${CFG.dryRun}`);

  await runCheck();

  setInterval(runCheck, CFG.windowMins * 60 * 1000);
  log(`Scheduler armed — next run in ${CFG.windowMins} min.`);
}

main().catch(err => { console.error('[FATAL]', err); process.exit(1); });
